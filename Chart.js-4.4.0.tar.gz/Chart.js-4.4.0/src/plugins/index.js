export {default as Colors} from './plugin.colors.js';
export {default as Decimation} from './plugin.decimation.js';
export {default as Filler} from './plugin.filler/index.js';
export {default as Legend} from './plugin.legend.js';
export {default as SubTitle} from './plugin.subtitle.js';
export {default as Title} from './plugin.title.js';
export {default as Tooltip} from './plugin.tooltip.js';
